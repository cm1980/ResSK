import xbmcaddon

MainBase = 'https://www.dropbox.com/scl/fi/ay9nsua3kac1jpyud2iqu/home.txt?rlkey=o63s347pwcju7znzhtkh6s2b6&dl=1'
addon = xbmcaddon.Addon('plugin.video.Redemption')